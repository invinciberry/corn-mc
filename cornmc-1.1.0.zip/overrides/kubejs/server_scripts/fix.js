ServerEvents.recipes(event => {
    event.recipes.gtceu.macerator('gtceu:obsidian_dust')
        .itemInputs("minecraft:obsidian")
        .itemOutputs("gtceu:obsidian_dust")
        .EUt(2)
        .duration(100)
})