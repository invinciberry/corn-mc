---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英火把
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# 石英火把

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

充能石英火把是一种能发光的小物件。

光亮探测器则会根据所处方块的光照等级发出红石信号。

## 配方

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
